#!/usr/bin/env bash
# Generate test phrases offline with Piper (https://github.com/rhasspy/piper).
# The prefix before "__" sets the mood: normal, affection, laugh, squawk.
#
#   ./make_phrases.sh /path/to/voice.onnx
#
# Any WAV works too - you can record your own voice and name it e.g.
# "affection__mwah.wav". If your Piper version uses a different command
# line, change the PIPER line below.
set -euo pipefail

VOICE="${1:?usage: ./make_phrases.sh /path/to/voice.onnx}"
OUT="$(dirname "$0")/phrases"
mkdir -p "$OUT"

say() {  # say <file-name> <text>
  echo "$2" | piper --model "$VOICE" --output_file "$OUT/$1.wav"
  echo "made $1.wav"
}

say "normal__hello"      "Hello! Hello there."
say "normal__super_bub"  "Super bub!"
say "normal__wow"        "Wow."
say "normal__good_boy"   "Good boy. Good boy!"
say "normal__boop"       "Boop boop boop."
say "affection__kiss"    "Do you want a kiss? Mwah!"
say "laugh__ha_ha"       "Ha ha haaa!"
say "squawk__bagawk"     "Bagawk!"
