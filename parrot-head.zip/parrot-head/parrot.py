"""
Parrot behaviour, based on the Eclectus reference video:

  * snap, then freeze - never drift
  * spend most of the time in side profile, watching with one eye
  * snap to face forward just before speaking, turn away mid-phrase
  * lean in slowly for affectionate lines
  * small head twitches on syllables; the beak barely moves when talking
"""
import os
import random
import subprocess
import threading
import time
import wave

import numpy as np

import config


# ------------------------------------------------------------ audio analysis

def loudness_envelope(path, rate_hz=config.UPDATE_HZ):
    """Return (envelope 0..1 sampled at rate_hz, duration in seconds)."""
    with wave.open(path, "rb") as w:
        n_ch, width, sr, n = w.getnchannels(), w.getsampwidth(), w.getframerate(), w.getnframes()
        raw = w.readframes(n)
    dtype = {1: np.uint8, 2: np.int16, 4: np.int32}[width]
    x = np.frombuffer(raw, dtype=dtype).astype(np.float32)
    if width == 1:
        x -= 128
    if n_ch > 1:
        x = x.reshape(-1, n_ch).mean(axis=1)
    hop = max(1, int(sr / rate_hz))
    frames = len(x) // hop
    if frames == 0:
        return np.zeros(1), n / sr
    rms = np.sqrt((x[: frames * hop].reshape(frames, hop) ** 2).mean(axis=1))
    ref = np.percentile(rms, 95) or 1.0
    return np.clip(rms / ref, 0, 1), n / sr


def mood_from_filename(path):
    """'laugh__ha_ha.wav' -> 'laugh'. Unknown/absent prefix -> 'normal'."""
    name = os.path.basename(path)
    mood = name.split("__", 1)[0] if "__" in name else "normal"
    return mood if mood in config.BEAK_OPEN_FRACTION else "normal"


# ------------------------------------------------------------------- parrot

class Parrot:
    def __init__(self, head, sim=False, seed=None):
        self.head = head
        self.sim = sim
        self.rng = random.Random(seed)
        self.side = self.rng.choice((-1, 1))   # which eye is currently "watching"
        self._body = threading.Lock()          # whoever holds this drives the head
        self._interrupt = threading.Event()
        self._speaking = False
        self._running = False
        self._idle_thread = None

    # ---------------------------------------------------------------- helpers

    def _hold(self, seconds):
        """Freeze for a while. Returns True if interrupted (time to talk)."""
        return self._interrupt.wait(seconds)

    def _r(self, lo_hi):
        return self.rng.uniform(*lo_hi)

    def _profile(self, side=None):
        side = side if side is not None else self.side
        return side * self._r(config.PROFILE_ANGLE)

    # ----------------------------------------------------------- idle actions

    def stare_profile(self):
        """Snap to a one-eye stare and hold it, with tiny adjustments."""
        if self.rng.random() < 0.5:
            self.side = -self.side
        base_turn, base_nod = self._profile(), self._r((-5, 5))
        self.head.turn.snap(base_turn)
        self.head.nod.snap(base_nod)
        end = time.monotonic() + self._r((1.5, 5.0))
        while time.monotonic() < end:
            if self._hold(self._r((0.4, 1.5))):
                return
            self.head.turn.snap(base_turn + self._r((-4, 4)))
            self.head.nod.snap(base_nod + self._r((-3, 3)))

    def glance_front(self):
        self.head.turn.snap(self._r((-5, 5)))
        self.head.nod.snap(self._r((-3, 2)))
        self._hold(self._r((0.6, 2.0)))

    def double_take(self):
        """Quick look to the other side, then straight back."""
        start = self.head.turn.pos
        self.head.turn.snap(self._profile(-self.side))
        if self._hold(self._r((0.3, 0.6))):
            return
        self.head.turn.snap(start)
        self._hold(self._r((0.8, 1.5)))

    def curious_lean(self):
        self.head.nod.move(self._r((config.LEAN_ANGLE - 4, config.LEAN_ANGLE + 3)), self._r((0.8, 1.2)))
        if self._hold(self._r((1.8, 3.0))):
            return
        self.head.nod.move(0, 0.6)
        self._hold(0.7)

    def beak_fidget(self):
        """A couple of little beak clacks."""
        beak_max = config.JOINTS["beak"]["limits"][1]
        for _ in range(self.rng.randint(2, 3)):
            self.head.beak.snap(beak_max * self._r((0.25, 0.4)))
            if self._hold(0.08):
                break
            self.head.beak.snap(0)
            if self._hold(self._r((0.12, 0.25))):
                break
        self.head.beak.snap(0)
        self._hold(0.5)

    IDLE_ACTIONS = (
        ("stare_profile", 45),
        ("glance_front", 20),
        ("double_take", 15),
        ("curious_lean", 10),
        ("beak_fidget", 10),
    )

    def idle_step(self):
        names, weights = zip(*self.IDLE_ACTIONS)
        getattr(self, self.rng.choices(names, weights)[0])()

    def _idle_loop(self):
        while self._running:
            if self._speaking:
                time.sleep(0.02)
                continue
            with self._body:
                if not self._speaking:
                    self.idle_step()

    def start_idle(self):
        self._running = True
        self._idle_thread = threading.Thread(target=self._idle_loop, daemon=True)
        self._idle_thread.start()

    def stop(self):
        self._running = False
        self._interrupt.set()
        if self._idle_thread:
            self._idle_thread.join(timeout=6)

    # ------------------------------------------------------------------ speech

    def say(self, wav_path, mood=None):
        """Play a WAV and animate beak and head to it. Blocks until finished."""
        mood = mood or mood_from_filename(wav_path)
        env, duration = loudness_envelope(wav_path)

        self._speaking = True
        self._interrupt.set()
        with self._body:
            self._interrupt.clear()
            try:
                self._perform(wav_path, mood, env, duration)
            finally:
                self._speaking = False

    def _perform(self, wav_path, mood, env, duration):
        head, rng, hz = self.head, self.rng, config.UPDATE_HZ
        beak_open = config.JOINTS["beak"]["limits"][1] * config.BEAK_OPEN_FRACTION[mood]

        # 1. Snap to face the listener, tiny anticipation pause
        head.turn.snap(self._r((-5, 5)))
        head.nod.snap(0)
        time.sleep(0.15)

        # 2. Start the audio
        proc = None
        if not self.sim:
            proc = subprocess.Popen(config.AUDIO_CMD + [wav_path])
        t0 = time.monotonic() + config.AUDIO_LATENCY_S

        lean = mood == "affection"
        turn_away_at = duration * self._r((0.4, 0.6)) if (duration > 1.5 and not lean) else None
        turned = False
        beak = prev_e = 0.0
        twitch_until, twitch_nod, twitch_turn = 0.0, 0.0, 0.0
        base_turn = head.turn.pos

        while True:
            now = time.monotonic()
            t = now - t0
            if t > duration:
                break
            idx = int(t * hz)
            e = float(env[idx]) if 0 <= idx < len(env) else 0.0

            # Beak: follows loudness, opens fast, closes a bit slower
            level = max(0.0, (e - config.ENVELOPE_FLOOR) / (1 - config.ENVELOPE_FLOOR)) ** 0.7
            target = beak_open * level
            beak += (target - beak) * (0.6 if target > beak else 0.3)
            head.beak.snap(beak)

            # Head base pose: lean in for affection, turn away mid-phrase otherwise
            base_nod = config.LEAN_ANGLE * min(1.0, max(0.0, t) / config.LEAN_TIME_S) if lean else 0.0
            if turn_away_at is not None and not turned and t >= turn_away_at:
                base_turn = self._profile()
                turned = True

            # Syllable twitch: a quick little jolt on each new burst of sound
            if e - prev_e > config.ONSET_LEVEL * 0.5 and e > config.ONSET_LEVEL and now > twitch_until:
                twitch_nod = rng.choice((-1, 1)) * self._r(config.TWITCH_DEG)
                twitch_turn = rng.choice((-1, 1)) * self._r(config.TWITCH_DEG)
                twitch_until = now + config.TWITCH_TIME_S
            if now > twitch_until:
                twitch_nod = twitch_turn = 0.0

            head.nod.snap(base_nod + twitch_nod)
            head.turn.snap(base_turn + twitch_turn)
            prev_e = e
            time.sleep(1.0 / hz)

        if proc:
            proc.wait()
        head.beak.snap(0)
        if lean:
            time.sleep(0.4)
            head.nod.move(0, 0.6)
        self._hold(0.5)
