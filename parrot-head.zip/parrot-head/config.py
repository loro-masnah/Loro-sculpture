"""
Parrot head configuration.

Every joint uses "logical" angles so the behaviour code never needs to know
how a servo is mounted:

  turn : 0 = facing straight ahead, negative = parrot's left, positive = right
  nod  : 0 = neutral, positive = lean forward/down, negative = head up/back
  beak : 0 = closed, positive = open (degrees of servo travel)

Calibrate each joint with calibrate.py, then fill in `center`, `direction`
and `limits` below.
"""

UPDATE_HZ = 50  # motion and beak update rate

# PCA9685 servo driver
I2C_ADDRESS = 0x40
DRIVER_CHANNELS = 16

JOINTS = {
    # Channel 0 - TURN (pan). Base of the neck, vertical axis, under the
    # lazy-susan bearing. The star of the show: profile stares and snaps.
    "turn": {
        "channel": 0,
        "pulse_us": (500, 2500),   # widen/narrow to match your servo's datasheet
        "actuation_range": 180,    # degrees the servo covers over pulse_us
        "center": 90,              # raw servo angle when the head faces forward
        "direction": 1,            # set to -1 if the head turns the wrong way
        "limits": (-85, 85),       # logical safe range - set after calibration
    },
    # Channel 1 - NOD (pitch). Sits on the turntable, turns with the head.
    # Lean-in for affection, little twitches on syllables.
    "nod": {
        "channel": 1,
        "pulse_us": (500, 2500),
        "actuation_range": 180,
        "center": 90,
        "direction": 1,
        "limits": (-15, 30),
    },
    # Channel 2 - BEAK. Inside the head, drives the lower mandible hinge
    # through a short pushrod.
    "beak": {
        "channel": 2,
        "pulse_us": (500, 2500),
        "actuation_range": 180,
        "center": 90,              # raw angle when the beak is CLOSED
        "direction": 1,
        "limits": (0, 25),         # 0 = closed, 25 = widest safe open
    },
    # Channel 3 - reserved for an optional TILT (roll) servo later.
}

# ---------------------------------------------------------------- behaviour

# Idle: how far round the head goes for a one-eye profile stare
PROFILE_ANGLE = (65, 85)

# Beak opening while talking, as a fraction of the beak's max limit.
# Real parrots barely move the beak when they talk - keep this small.
BEAK_OPEN_FRACTION = {
    "normal": 0.35,
    "affection": 0.30,
    "laugh": 0.8,
    "squawk": 1.0,
}

# Affectionate lean (nod angle) and how long the lean takes
LEAN_ANGLE = 22
LEAN_TIME_S = 0.8

# Speech-sync tuning
AUDIO_LATENCY_S = 0.08   # delay between starting playback and hearing it
ENVELOPE_FLOOR = 0.08    # loudness below this = beak closed
ONSET_LEVEL = 0.45       # loudness jump that counts as a new syllable
TWITCH_DEG = (2, 4)      # size of the head twitch on a syllable
TWITCH_TIME_S = 0.12

# Audio playback command (BrainCraft uses ALSA). Add "-D", "<device>" if needed.
AUDIO_CMD = ["aplay", "-q"]
