# Parrot Head – Prototype 1

Three-servo animatronic parrot head driven by a Raspberry Pi 4 + Adafruit BrainCraft HAT.
Movements are based on the Eclectus reference video: **snap, then freeze**, one-eye profile
stares, lean-in for affection, and a beak that barely moves when talking.

**Shopping list:** see [PARTS.md](PARTS.md).

## Servo map

| Ch | Joint | Where it goes | What it does | Servo to buy |
|----|-------|---------------|--------------|--------------|
| 0 | **TURN** (pan) | Base of the neck, vertical axis, under a lazy-susan bearing | Profile stares, snap to face you, double-takes, turn away mid-phrase. Range about ±85° | Standard-size **digital, metal-gear, 180°**, fast: **0.10 s/60° or quicker at 6 V**, ~10 kg·cm+. Speed matters most here. |
| 1 | **NOD** (pitch) | Neck hinge, mounted on the turntable so it turns with the head | Slow affectionate lean-in, small twitches on syllables. Range about −15° to +30° | Standard-size **digital, metal-gear**, ~15–20 kg·cm+ (depends on head weight). Speed less critical. |
| 2 | **BEAK** | Inside the head, pushrod to the lower-mandible hinge | Subtle opening with speech, wide only for laughs and squawks, idle clacks. Range 0–25° | **Micro metal-gear** (MG90S class, 9 g) |
| 3 | *(spare)* TILT (roll) | Between nod hinge and head | Optional later: sideways head cock | Micro or standard |

Choose quiet servos where you can. In a gallery, gear whine is audible.

## Mechanical stack

```
            ┌──────────── HEAD SHELL ────────────┐
            │  BEAK servo (ch2) ──pushrod──► lower beak hinge
            └───────────────┬────────────────────┘
                            │
                NOD hinge ◄─┤ NOD servo (ch1), horizontal axis
                            │   (add a spring/elastic counterbalance)
                ════════════╧════════════  turntable plate
                ░░░░ lazy-susan bearing ░░░░  carries the head's weight
                            │
                   TURN servo (ch0), vertical axis,
                   horn bolted to the turntable
                            │
                      neck / base mount
```

* The **bearing carries the weight**; the turn servo only rotates. This keeps it fast and long-lived.
* **Counterbalance** the nod axis with a spring or elastic so the servo isn't holding the head up all day.
  That makes it quieter and makes it last longer.
* Run servo cables through the centre of the bearing with a **service loop** that allows the full ±90° turn without tugging.
* Make every servo reachable without breaking the sculpture: they are the parts that wear out.

## Wiring

```
Pi 4 + BrainCraft ──STEMMA QT-to-female-socket cable (I²C)──► PCA9685 servo driver
                                              ├─ ch0 TURN
6 V 5 A regulated supply ──► driver V+ / GND  ├─ ch1 NOD
                                              └─ ch2 BEAK
```

* Power the servos from their **own 6 V (or 5 V) supply rated 5 A+**, into the driver's screw terminal.
  **Never** power them from the Pi's 5 V pin: a snapping turn servo can draw 2–3 A and will reset the Pi.
* The STEMMA QT cable shares ground between the Pi and the driver.
* Fit a large capacitor (about 1000 µF) across the driver's V+/GND to absorb current spikes.

## Software setup (on the Pi)

```bash
sudo raspi-config          # Interface Options → I2C → enable, then reboot
i2cdetect -y 1             # the servo driver should show up at 40
python3 -m venv --system-site-packages ~/parrot-env
source ~/parrot-env/bin/activate
pip install adafruit-circuitpython-servokit numpy
```

If the BrainCraft setup already made a Python environment, install into that instead.
If `40` clashes with another device in `i2cdetect`, change the driver's address jumper and `I2C_ADDRESS` in `config.py`.

## Build order

1. **Beak only, on the bench.** Connect just the beak servo, run `python3 calibrate.py`,
   find the closed angle and the widest safe open, and put them in `config.py`.
2. **Make phrases.** Run `./make_phrases.sh voice.onnx` (Piper, offline), or drop in your own WAVs.
   The filename prefix sets the mood: `normal__`, `affection__`, `laugh__`, `squawk__`.
3. **Run it:** `python3 demo.py`. The beak should move with the words.
4. **Add TURN and NOD** on a rough foam or 3D-printed skeleton, calibrate them, run again.
5. Tune the feel in `config.py` (below), then move on to the sculpture.

You can test everything without hardware: `python3 demo.py --sim --seconds 60 --log motion.csv`.

## Files

| File | Purpose |
|------|---------|
| `config.py` | Channels, calibration, and all behaviour tuning |
| `motion.py` | Servo control: instant snaps, smooth moves, safety limits, simulator |
| `parrot.py` | Behaviour: idle routines and speech-synced animation |
| `demo.py` | Runs the head: idles, says a random phrase every 8–20 s |
| `calibrate.py` | Interactive tool to find each servo's centre and limits |
| `make_phrases.sh` | Generates test phrases offline with Piper |

## Behaviour (from the reference video)

**Idle** (picked at random): profile stare with tiny adjustments 45%, glance front 20%,
double-take 15%, slow curious lean 10%, beak clacks 10%.

**Speaking:** snap to face the listener → short pause → talk (beak follows loudness, head
twitches on each syllable) → turn away to a profile mid-phrase. Affection phrases lean in instead.

## Tuning knobs (`config.py`)

| Setting | Effect |
|---------|--------|
| `BEAK_OPEN_FRACTION` | How wide the beak opens per mood. Keep `normal` small. |
| `AUDIO_LATENCY_S` | Raise it if the beak moves before the sound; lower it if it lags. |
| `ENVELOPE_FLOOR` | Raise it if the beak chatters on quiet noise. |
| `ONSET_LEVEL`, `TWITCH_DEG` | How often and how big the syllable twitches are. |
| `PROFILE_ANGLE`, `LEAN_ANGLE` | How far it looks away and how deep it leans. |

## Safety notes

* On start-up the servos jump to their neutral pose. Power up with the head roughly centred.
* `limits` in `config.py` are hard clamps. Set them just inside the mechanism's real ends.
* On exit (Ctrl-C) all servos go limp, so they stop buzzing.
