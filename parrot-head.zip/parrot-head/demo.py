"""
Run the parrot head: idles on its own and says a random phrase now and then.

  python3 demo.py                  # real servos + speaker
  python3 demo.py --sim            # no hardware, just simulates (and can log)
  python3 demo.py --sim --seconds 60 --log motion.csv
"""
import argparse
import csv
import glob
import os
import random
import time

from motion import Head
from parrot import Parrot


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sim", action="store_true", help="no hardware; simulate servos and audio")
    ap.add_argument("--phrases", default=os.path.join(os.path.dirname(__file__), "phrases"))
    ap.add_argument("--talk-every", type=float, nargs=2, default=(8, 20),
                    metavar=("MIN", "MAX"), help="seconds of idling between phrases")
    ap.add_argument("--seconds", type=float, default=0, help="stop after N seconds (0 = forever)")
    ap.add_argument("--log", help="(sim) write every servo command to this CSV")
    ap.add_argument("--seed", type=int)
    args = ap.parse_args()

    phrases = sorted(glob.glob(os.path.join(args.phrases, "*.wav")))
    print(f"{len(phrases)} phrase(s) found in {args.phrases}")

    head = Head(sim=args.sim)
    parrot = Parrot(head, sim=args.sim, seed=args.seed)
    rng = random.Random(args.seed)
    start = time.monotonic()

    try:
        head.home()
        parrot.start_idle()
        while True:
            wait = rng.uniform(*args.talk_every)
            if args.seconds:
                wait = min(wait, max(0, start + args.seconds - time.monotonic()))
            time.sleep(wait)
            if args.seconds and time.monotonic() - start >= args.seconds:
                break
            if phrases:
                p = rng.choice(phrases)
                print("saying", os.path.basename(p))
                parrot.say(p)
    except KeyboardInterrupt:
        pass
    finally:
        parrot.stop()
        head.shutdown()
        if args.sim and args.log:
            with open(args.log, "w", newline="") as f:
                w = csv.writer(f)
                w.writerow(["t", "joint", "raw_angle"])
                for t, name, a in head.backend.log:
                    w.writerow([f"{t - start:.3f}", name, "" if a is None else f"{a:.2f}"])
            print("wrote", args.log)


if __name__ == "__main__":
    main()
