"""
Calibrate each servo BEFORE the head linkage is fully attached.

Type commands at the prompt:
  turn 90        move the TURN servo to raw angle 90
  nod 100        move the NOD servo to raw angle 100
  beak 85        move the BEAK servo to raw angle 85
  + / -          nudge the last joint by 1 degree   (++ / -- for 5 degrees)
  off            relax all servos (go limp)
  q              quit

For each joint, find:
  * center  - raw angle for: head facing forward / neck neutral / beak CLOSED
  * the raw angles where the mechanism just reaches its safe ends
Then put them in config.py ("center", "direction", "limits").
Move in small steps near the ends - never hold a servo against a hard stop.
"""
import config
from motion import HardwareBackend


def main():
    backend = HardwareBackend()
    servos = {n: backend.servo(dict(c, _name=n)) for n, c in config.JOINTS.items()}
    angles = {n: None for n in servos}
    last = None
    print(__doc__)
    while True:
        try:
            cmd = input("> ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            break
        if cmd in ("q", "quit", "exit"):
            break
        if cmd == "off":
            for s in servos.values():
                s.angle = None
            continue
        if cmd in ("+", "-", "++", "--") and last and angles[last] is not None:
            step = {"+": 1, "-": -1, "++": 5, "--": -5}[cmd]
            target = angles[last] + step
            name = last
        else:
            parts = cmd.split()
            if len(parts) != 2 or parts[0] not in servos:
                print("usage: <turn|nod|beak> <angle>, + / - / ++ / --, off, q")
                continue
            name, target = parts[0], float(parts[1])
        rng = config.JOINTS[name]["actuation_range"]
        target = max(0, min(rng, target))
        servos[name].angle = target
        angles[name], last = target, name
        print(f"{name}: raw {target:.0f}")
    for s in servos.values():
        s.angle = None


if __name__ == "__main__":
    main()
