"""
Low-level motion: joints, smooth moves, instant snaps, hardware/simulator backends.
"""
import math
import threading
import time

import config


def ease_in_out(t):
    return 0.5 - 0.5 * math.cos(math.pi * t)


# ------------------------------------------------------------------ backends

class HardwareBackend:
    """Real servos on an Adafruit PCA9685 via ServoKit."""

    def __init__(self):
        from adafruit_servokit import ServoKit  # imported here so --sim works anywhere
        self.kit = ServoKit(channels=config.DRIVER_CHANNELS, address=config.I2C_ADDRESS)

    def servo(self, cfg):
        s = self.kit.servo[cfg["channel"]]
        s.set_pulse_width_range(*cfg["pulse_us"])
        s.actuation_range = cfg["actuation_range"]
        return s


class SimServo:
    def __init__(self, name, log):
        self.name, self._log, self._angle = name, log, None

    @property
    def angle(self):
        return self._angle

    @angle.setter
    def angle(self, value):
        self._angle = value
        if self._log is not None:
            self._log.append((time.monotonic(), self.name, value))


class SimBackend:
    """No hardware: records every servo command so motion can be checked."""

    def __init__(self):
        self.log = []

    def servo(self, cfg):
        return SimServo(cfg["_name"], self.log)


# -------------------------------------------------------------------- joints

class Joint:
    def __init__(self, name, cfg, backend):
        self.name = name
        self.cfg = dict(cfg, _name=name)
        self.servo = backend.servo(self.cfg)
        self.pos = 0.0
        self._tween = None
        self._lock = threading.Lock()

    def clamp(self, logical):
        lo, hi = self.cfg["limits"]
        return max(lo, min(hi, logical))

    def _write(self, logical):
        logical = self.clamp(logical)
        self.pos = logical
        raw = self.cfg["center"] + self.cfg["direction"] * logical
        raw = max(0, min(self.cfg["actuation_range"], raw))
        self.servo.angle = raw

    def snap(self, logical):
        """Go as fast as the servo can - the parrot 'snap'."""
        with self._lock:
            self._tween = None
            self._write(logical)

    def move(self, logical, duration, ease=ease_in_out):
        """Smooth, timed move (used for leans and slow looks)."""
        with self._lock:
            if duration <= 0:
                self._tween = None
                self._write(logical)
                return
            self._tween = (self.pos, self.clamp(logical), time.monotonic(), duration, ease)

    def update(self, now):
        with self._lock:
            if not self._tween:
                return
            start, end, t0, dur, ease = self._tween
            t = min(1.0, (now - t0) / dur)
            self._write(start + (end - start) * ease(t))
            if t >= 1.0:
                self._tween = None

    @property
    def moving(self):
        return self._tween is not None

    def relax(self):
        """Stop sending pulses so the servo goes limp and stops buzzing."""
        with self._lock:
            self._tween = None
            self.servo.angle = None


class Head:
    def __init__(self, sim=False):
        self.backend = SimBackend() if sim else HardwareBackend()
        self.joints = {n: Joint(n, c, self.backend) for n, c in config.JOINTS.items()}
        self.turn = self.joints["turn"]
        self.nod = self.joints["nod"]
        self.beak = self.joints["beak"]
        self._running = True
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def _loop(self):
        period = 1.0 / config.UPDATE_HZ
        while self._running:
            now = time.monotonic()
            for j in self.joints.values():
                j.update(now)
            time.sleep(period)

    def home(self, duration=1.5):
        """Gentle start-up: write the neutral pose, then hold it."""
        for j in self.joints.values():
            j.snap(0)
        time.sleep(duration)

    def shutdown(self):
        self._running = False
        self._thread.join(timeout=1)
        for j in self.joints.values():
            j.relax()
